﻿//Written by John
// 4/6/2021

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsSpring_2022
{
    public class Product:IDisposable
    {
        // Class variables
        private int productId = -1;
        private string productName = "n/a";
        private int categoryId = -1;
        private int supplierId = -1;
        private double unitPrice = 999999999.99;

        // Gets and sets
        public int ProductId
        {
            get { return this.productId; }
            set { this.productId = value; }
        }

        public string ProductName
        {
            get { return this.productName; }
            set { this.productName = value; }
        }

        public int CategoryId
        {
            get { return this.categoryId; }
            set { this.categoryId = value; }
        }
        public int SupplierId
        {
            get { return this.supplierId; }
            set { this.supplierId = value; }
        }
        public double UnitPrice
        {
            get { return this.unitPrice; }
            set { this.unitPrice = value; }
        }

        // Constructors

        public Product():this(-1,"n/a", -1, -1, 999999999.99)
        {
            // The empty Constructor

        }

        public Product(int aProductId, string aProductName, int aSupplierId, int aCategoryId, double aUnitPrice)
        {
            this.ProductId = aProductId;
            this.ProductName = aProductName;
            this.SupplierId = aSupplierId;
            this.CategoryId = aCategoryId;
            this.UnitPrice = aUnitPrice;
        }



        // methods
        public override string ToString()
        {
            string message = "";
            message = message + "Product Id: " + this.ProductId + "\n";
            message = message + "Product Name: " + this.ProductName + "\n";
            message = message + "Category Id: " + this.CategoryId + "\n";
            message = message + "Supplier Id: " + this.SupplierId + "\n";
            message = message + "Unit Price: " + this.UnitPrice + "\n\n";
            return message;
        }

        public void Dispose()
        {
            this.Dispose();
        }
    }
}
