﻿// Written by John
// 1/27/2022

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ProductsSpring_2022
{
    public class FileGateway
    {

        private List<Product> listOfProducts = new List<Product>();
        private string[] allRows = null;
        private string[] allColumns = null;
        private Product aProduct = null;
        private int index = 1;

        private string path = "C:/Users/xb9211dq/Documents/courses/Spring 2022/Products.csv";

        public List<Product> GetProducts()
        {
            allRows = File.ReadAllLines(path);


            while (index < allRows.Length)
            {
                aProduct = new Product();

                allColumns = allRows[index].Split(',');

                aProduct.ProductId = Convert.ToInt32(allColumns[0]);
                aProduct.ProductName = allColumns[1];
                aProduct.SupplierId = Convert.ToInt32(allColumns[2]);
                aProduct.CategoryId = Convert.ToInt32(allColumns[3]);
                aProduct.UnitPrice = Convert.ToDouble(allColumns[4]);


                listOfProducts.Add(aProduct);
                index = index + 1;

            }

            return listOfProducts;

        }

    }
}
