﻿// Written by John
// 1/27/2022

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsSpring_2022
{
    public class Program
    {
        public static void Main(string[] args)
        {
            FileGateway aGateway = new FileGateway();
            List<Product> aListOfProducts = new List<Product>();

            aListOfProducts = aGateway.GetProducts();

            foreach(var p in aListOfProducts)
            {
                Console.WriteLine(p.ToString());
            }

            Console.ReadLine();

        }
    }
}
